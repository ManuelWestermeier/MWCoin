import { useEffect, useState } from 'react'
import Menue from './comp/Menue/index.jsx'
import Home from './comp/Home/index.jsx'
import Invests from './comp/Invests/index.jsx'
import Contacts from './comp/Contacts/index.jsx'
import Profile from './comp/Profile/index.jsx'

function App() {

  const [page, _setPage] = useState(localStorage.getItem("page") || "home")
  const [opacity, setOpacity] = useState("100%")
  const [isFirst, setIsFirst] = useState(true)

  var setPage = (x) => {
    setOpacity(0);
    setTimeout(() => {
      _setPage(x)
      setOpacity(1)
    }, 200);
  }

  useEffect(() => {
    document.title = ("MW COIN | " + page).toUpperCase();
    localStorage.setItem("page", page);
  }, [page])

  useEffect(() => {

    var url = new URL(document.location);
    if (!url.searchParams.get("addConatct")) return;
    setPage("contacts");
    history.pushState("", "", "/");

  }, [isFirst])

  return (
    <>
      <div onContextMenuCapture={e => { e.preventDefault() }}>
        <Menue page={page} setPage={setPage} />
        <div className='pages-transition-div' style={{ opacity }}>
          <div className={page == "home" ? "page" : "none"}>
            <Home />
          </div>
          <div className={page == "invests" ? "page" : "none"}>
            <Invests setPage={setPage} />
          </div>
          <div className={page == "contacts" ? "page" : "none"}>
            <Contacts />
          </div>
          <div className={page == "me" ? "page" : "none"}>
            <Profile setPage={setPage} />
          </div>
        </div>
      </div>
    </>
  )

}

export default App