import { useEffect, useState } from "react"
import { contacts, set, me } from "../../api/contacts";
import GetUserData from "./GetUserData/index.jsx";
import "./index.css"
var isSatrt = true;

export var contactFunction, setContactFunction;

export default function Contacts({ }) {
    [contactFunction, setContactFunction] = useState("see");
    var [_contacts, setContacts] = useState(contacts)

    var [fn, user] = contactFunction.split("\n")

    useEffect(() => {

        if (!isSatrt) return;
        isSatrt = false;
        var url = new URL(document.location);
        if (!url.searchParams.get("addConatct")) return;
        if (!url.searchParams.get("id") || !url.searchParams.get("name")) return;
        document.getElementById("ConatctIDInput").value = url.searchParams.get("id");
        document.getElementById("ConatctNameInput").value = url.searchParams.get("name");
        window.history.pushState("", "", "/");

    }, [])

    return <>
        {
            fn == "see" ? <>
                <fieldset>
                    <legend><h3>Share your User</h3></legend>
                    <p>
                        <a
                            href="#"
                            onClick={async e => {
                                e.preventDefault()
                                const shareData = {
                                    title: "MWC",
                                    text: "My contact on MWC",
                                    url: getProfileLink(),
                                };
                                try {
                                    await navigator.share(shareData)
                                } catch (error) {
                                    var a = document.createElement("a")
                                    var link = new URL("https://api.whatsapp.com/send?text=true")
                                    link.searchParams.set("text", shareData.url);
                                    a.href = link.toString();
                                    a.target = "_blank";
                                    a.click()
                                }
                            }}
                        >
                            Share Your User
                        </a>
                    </p>
                </fieldset>
                <br />
                <fieldset>
                    <legend><h4>Add Conatct</h4></legend>
                    <form
                        style={{
                            display: "grid",
                            placeItems: "center",
                        }}
                        onSubmitCapture={e => {
                            e.preventDefault();
                            set(
                                document.getElementById("ConatctIDInput").value,
                                document.getElementById("ConatctNameInput").value
                            );
                            setContacts(ct => {
                                return {
                                    ...ct,
                                    [document.getElementById("ConatctIDInput").value]:
                                        document.getElementById("ConatctNameInput").value
                                }
                            });
                        }}
                    >
                        <input id="ConatctIDInput" type="text" placeholder="Conatct ID" />
                        <input id="ConatctNameInput" type="text" placeholder="Conatct Name" />
                        <button style={{ margin: "10px" }}>
                            Add Contact
                        </button>
                    </form>
                </fieldset>
                <br />
                <GetContacts contacts={contacts} />
            </> :
                fn == "visit" ? <GetUserData setContactFunction={setContactFunction} user={user} />
                    : "User doesn't exists"
        }
    </>
}

var GetContacts = ({ contacts }) =>
    Object.keys(contacts).map((key, index) =>
        <div className="contact" key={index}>
            <h2 onClick={e => {
                setContactFunction("visit\n" + key);
            }}>{contacts[key]}</h2>
        </div>)

export var getProfileLink = () => {
    var url = new URL(document.location.origin);
    url.searchParams.set("addConatct", true);
    url.searchParams.set("id", me);
    url.searchParams.set("name", "Add Me");
    return url.toString();
}