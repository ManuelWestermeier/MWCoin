import "./index.css"
import { API } from "../../API.jsx"
import { contacts, me } from "../../api/contacts.jsx";
import { useState } from "react";

function invest({ money, other, text }) {
    API.say("sendMoney", {
        money,
        other,
        text,
    });
}

export default function Profile({ setPage }) {

    const [money, setMoney] = useState(1);
    const [other, setOther] = useState(me);
    const [text, setText] = useState("Default Text...");

    return <>
        <fieldset>
            <legend><h1>Invest</h1></legend>
            <form
                className="invest-form"
                onSubmit={e => {
                    e.preventDefault();
                    if (!confirm("Are you shure you want to " + `send ${money}MWC to ${contacts[other]}`)) return;
                    setPage("invests");
                    invest({
                        money,
                        other,
                        text,
                    });
                }}
            >

                <p>
                    <label htmlFor="m" style={{ margin: "10px" }}>To User : </label>
                    <select
                        onChangeCapture={e => {
                            setOther(e.target.value)
                        }}
                        defaultValue={other}
                    >
                        {
                            Object.keys(contacts).map(key => <option key={key} value={key}>{contacts[key]}</option>)
                        }
                    </select>
                </p>

                <p>
                    <label htmlFor="m" style={{ margin: "10px" }}>To User : </label>
                    <textarea
                        onInput={e => {
                            setText(e.target.value)
                        }}
                        defaultValue={text}
                        placeholder="Default Text..."
                    >
                    </textarea>
                </p>

                <p>
                    <label htmlFor="m" style={{ margin: "10px" }}>Money : </label>
                    <input
                        id="m"
                        onInputCapture={e => {
                            setMoney(Math.abs(parseFloat(e.target.value)))
                        }}
                        defaultValue={money}
                        placeholder="new name..." type="number"
                    />
                    <a style={{ margin: "5px" }} target="_blank" href="MWC_TAX.html">
                        (+MWC tax)
                    </a>
                </p>

                <button title={`send ${money}MWC to ${contacts[other]}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M120-160v-640l760 320-760 320Zm80-120 474-200-474-200v140l240 60-240 60v140Zm0 0v-400 400Z" /></svg>
                </button>
            </form>
        </fieldset>
    </>

}