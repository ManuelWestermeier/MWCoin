import { useState } from "react";
import "./index.css"
import GetInvests from "./GetInvests/index.jsx";
import { API, open } from "../../API.jsx"

var invests, setInvests;
export var money, setMoney;

open(async API => {

    API.say("money", {});

    var newInvests = [];
    (await API.get("getInvests", {})).invests.forEach(async _id => {
        newInvests.unshift({ ...(await API.get("getInvest", { _id }))?.invest, id: _id });
        setInvests(newInvests);
    });

})

API.onSay("newInvest", ({ sender, user, money, date, text, id }) => {

    var newInvest = {
        sender,
        user,
        money,
        date,
        text,
        id,
    };
    setInvests(inv => [
        newInvest,
        ...inv,
    ]);

})

API.onSay("money", ({ money }) => {
    setMoney(money)
})

export default function Invests({ setPage }) {

    [invests, setInvests] = useState([]);
    [money, setMoney] = useState(1000)


    return <>
        <h1 style={{ margin: "10px" }}>Money : {money}</h1>
        <fieldset>
            <legend>
                <h2>Invests</h2>
            </legend>
            <GetInvests setPage={setPage} invests={invests} />
        </fieldset>
    </>
}