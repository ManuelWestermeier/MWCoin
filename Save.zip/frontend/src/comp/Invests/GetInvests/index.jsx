import GetInvest from "./GetInvest/index.jsx";
import { useState } from "react";

export default function GetInvests({ invests, setPage }) {

    const [display, setDisplay] = useState("");

    return <fieldset>
        <legend
            style={{
                cursor: "pointer",
                userSelect: "none"
            }}
            onClick={e => {
                setDisplay(d => d == "none" ? "" : "none");
            }}
        >
            All Invests
            <span style={{ fill: "gold", display: "flex", placeItems: "center" }}>
                {display == "none" ?
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z" /></svg> :
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="m296-345-56-56 240-240 240 240-56 56-184-184-184 184Z" /></svg>
                }
            </span>
        </legend>
        <div style={{ display }}>
            {invests.map((data, index) => {
                return <div key={index}>
                    <GetInvest canSee={index == 0} setPage={setPage} data={data} />
                </div>
            })}
        </div>
    </fieldset>

}