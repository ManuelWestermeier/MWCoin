import { setUser } from "./api/contacts";
import { Socket, getID } from "./api/index";
var url = document.location.protocol == "http:" ? "ws://localhost:8888" : "wss://zl6rrt5t-8888.euw.devtunnels.ms"
export var API = new Socket({ url });

var openings = [];

API.onOpen = async e => {

    await auth()

    openings.forEach(cb => cb(API))

}

export var open = (cb) => openings.push(cb);

async function auth() {

    var password = localStorage.getItem("password") || false;
    var _user = localStorage.getItem("user") || false;

    if (!password || !_user) {
        password = getID(30);
        _user = getID(20);
        localStorage.setItem("password", password);
        localStorage.setItem("user", _user);
        setUser(_user)
    }

    await API.get("auth", { password, _user });

}