export var contacts = JSON.parse(localStorage.getItem("contacts")) ?? {};

export var me = localStorage.getItem("user");

contacts = {
    ...contacts,
    [me]: "You",
};

export function set(key, name) {

    contacts = {
        ...contacts,
        [key]: name
    };

    localStorage.setItem("contacts", JSON.stringify(contacts));

}

export function setUser(name) {
    me = name;
}