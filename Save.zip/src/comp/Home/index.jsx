import "./index.css"

export default function Home({ }) {
    return <>
        <header className="header">
            <img className="header-image" src="./coin.webp" />
            <h1>Wellcome To MWC</h1>
        </header>
    </>
}