import { useEffect, useState } from "react"
import { contacts, set } from "../../../api/contacts";
import "./index.css"

export default function GetUserData({ user, setContactFunction }) {
    const [userName, setUserName] = useState(contacts[user] ?? user);

    useEffect(() => {
        set(user, userName);
    }, [userName]);

    return <fieldset className="UserPata">
        <legend>
            <h3>{userName}</h3>
        </legend>
        <p style={{ margin: "5px" }}>Chane name</p>
        <input onInputCapture={e => {
            setUserName(e.target.value)
        }} placeholder="new name..." type="text" defaultValue={userName} />
        <button>Save</button>
        <button
            onClickCapture={e => {
                setContactFunction("see");
            }}
            className="close-button">
            <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="m313-440 224 224-57 56-320-320 320-320 57 56-224 224h487v80H313Z" /></svg>
        </button>
        <button
            onClick={e => {
                delete contacts[user];
                localStorage.setItem("contacts", JSON.stringify(contacts))
                setContactFunction("see");
            }}
            className="delete-button">
            <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M280-120q-33 0-56.5-23.5T200-200v-520h-40v-80h200v-40h240v40h200v80h-40v520q0 33-23.5 56.5T680-120H280Zm400-600H280v520h400v-520ZM360-280h80v-360h-80v360Zm160 0h80v-360h-80v360ZM280-720v520-520Z" /></svg>
        </button>
    </fieldset>
}