import { useState } from "react";
import { contacts, me } from "../../../../api/contacts.jsx"
import "./index.css"
import { setContactFunction } from "../../../Contacts/index.jsx";
import { API } from "../../../../API.jsx";

export default function GetInvest({ data: { sender, user, money, date, text, id }, canSee, setPage }) {

    const [display, setDisplay] = useState(canSee ? "" : "none");

    var text = text.legend < 300 ? text :
        [...text].slice(0, 300).join("");

    return (
        <fieldset className="invest">
            <Legend display={display} setDisplay={setDisplay} money={money} user={user} sender={sender} date={date}></Legend>
            <div style={{ display }}>
                <InvestHeader sender={sender} user={user} setPage={setPage} />
                <InvestMessage id={id} text={text} />
                <InvestFooter user={user} sender={sender} date={date} money={money} />
            </div>
        </fieldset>
    )

}

var InvestFooter = ({ user, sender, date, money }) =>
    <>
        <p>Money : <span style={{ color: (sender == me ? "yellowgreen" : user == me ? "red" : "gold") }}>
            {(sender == me ? "+" : user == me ? "-" : "")}
            {Math.abs(money)}
        </span>
        </p>
        <p>Date : {date}</p>
    </>

var InvestMessage = ({ text, id }) =>
    <div className="msg">
        <textarea
            onMouseOver={e => {
                e.preventDefault()
                e.target.style.height = ""; e.target.style.height = e.target.scrollHeight + "px"
            }}
            onBlurCapture={e => {
                API.say("setInvestText", {
                    id,
                    text: e.target.value,
                })
            }}
            defaultValue={text}></textarea>
    </div>

var InvestHeader = ({ sender, user, setPage }) =>
    <>
        <h3>
            to <span
                style={{ cursor: "pointer" }}
                onClickCapture={e => {
                    setContactFunction("visit\n" + sender);
                    setPage("contacts");
                }}
            >{contacts?.[sender] ?? sender}</span>
            {" "}from <span
                style={{ cursor: "pointer" }}
                onClickCapture={e => {
                    setContactFunction("visit\n" + user);
                    setPage("contacts");
                }}
            >{contacts?.[user] ?? user}</span>
        </h3>
    </>

var Legend = ({ setDisplay, user, money, display, sender, date }) =>
    <>
        <legend
            style={{
                cursor: "pointer",
                userSelect: "none"
            }}
            onClick={e => {
                setDisplay(d => d == "none" ? "" : "none");
            }}
        >
            <span style={{ color: (sender == me ? "yellowgreen" : user == me ? "red" : "gold"), marginRight: "5px" }}>
                {(sender == me ? "+" : user == me ? "-" : "")}
                {Math.abs(money)}
            </span>
            {date}
            <span style={{ fill: "gold", display: "flex", placeItems: "center" }}>
                {display == "none" ?
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="M480-345 240-585l56-56 184 184 184-184 56 56-240 240Z" /></svg> :
                    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 -960 960 960" width="24"><path d="m296-345-56-56 240-240 240 240-56 56-184-184-184 184Z" /></svg>
                }
            </span>
        </legend>
    </>