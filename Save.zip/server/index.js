const { log } = require("console");
const { CreateApi, getID } = require("./lib");
const { writeFileSync, readFileSync } = require("fs");

var adminMoney = 0;

var obj;

if (false) {
    obj = {
        user: {},
        invest: {},
        sockets: {},
    };
} else {
    obj = JSON.parse(readFileSync("data.json", "utf-8"));
    obj.sockets = {}
}

CreateApi({ port: 8888 }, async client => {

    const id = getID(6);
    var auth = false;
    var user = false;

    client.onGet("auth", ({ password, _user }) => {
        try {

            var err = false;

            if (!password || !_user)
                err = true;

            if (password.length != 20 || _user.length != 30)
                err = true;

            if (obj.user?.[_user]) {
                if (obj.user?.[_user]?.password == password) {
                    auth = true;
                    user = _user;
                }
                else err = true;
            }
            else {
                obj.user[_user] = {
                    password,
                    contacts: {},
                    invests: [],
                    money: 10 ** 7,
                };
                auth = true;
                user = _user;
            }

            if (auth) {
                if (obj.sockets?.[user])
                    obj.sockets[user][id] = client;
                else obj.sockets[user] = { [id]: client }
            }

            return { err };

        } catch (err) {
            return { err };
        }
    })

    client.onSay("money", res => {
        if (!auth) return
        client.say("money", { money: obj.user[user].money })
    })

    client.onGet("getInvests", res => {
        try {
            if (!auth)
                return { err: true };
            var err = false;
            var invests = false;

            if (obj.user?.[user])
                invests = obj.user[user].invests;
            else err = true;

            return { err, invests };

        } catch (err) { return { err } }
    })

    client.onGet("getInvest", ({ _id }) => {
        try {
            if (!auth)
                return { err: true };
            if (!_id)
                throw new Error("no _ID")
            var err = false;
            var invest = false;

            if (obj.invest?.[_id])
                invest = obj.invest[_id];
            else err = true;

            return { err, invest };

        } catch (err) { return { err } }
    })

    client.onSay("setInvestText", ({ id, text }) => {
        if (!auth) return;
        if (id && text)
            if (obj.invests?.[id]) {
                if (obj.invests[id].user == user || obj.invests[id].sender == user)
                    obj.invests[id].text = text;
            }

    })

    client.onSay("sendMoney", ({ money, other, text }) => {

        if (!money, !other, !text) return;
        if (text.length > 302) return;
        if (money < 0) return;
        if (!obj.user?.[user]) return
        if (!obj.user?.[other]) return
        if (obj.user[user].money - money < 0) return;

        if (money < 10000) {
            var myWinn = money * 0.001;
            obj.user[user].money -= myWinn;
            adminMoney += myWinn;
        } else {
            var myWinn = (money * 0.0001) + 3;
            obj.user[user].money -= myWinn;
            adminMoney += myWinn;
        }

        var id = getID(30);
        obj.invest[id] = {
            money,
            sender: other,
            user,
            text,
            date: new Date().toLocaleDateString(),
            id,
        };

        obj.user[user].money -= money;
        obj.user[user].invests.push(id);
        obj.user[other].money += money;
        obj.user[other].invests.push(id);
        //Emit for each socket
        if (obj.sockets[user])
            Object.keys(obj.sockets[user]).forEach(key => {
                obj.sockets[user][key].say("newInvest", obj.invest[id]);
                obj.sockets[user][key].say("money", { money: obj.user[user].money })
            })
        if (user == other) return;
        if (obj.sockets[other])
            Object.keys(obj.sockets[other]).forEach(key => {
                obj.sockets[other][key].say("newInvest", obj.invest[id]);
                obj.sockets[other][key].say("money", { money: obj.user[other].money })
            })

    })

    client.onClose = () => { close() }
    client.onError = () => { close() }

    function close() {
        if (!auth) return;
        delete obj.sockets[user][id];
    }

})


setInterval(() => {
    writeFileSync("data.json", JSON.stringify({ ...obj, sockets: {} }, null, 4), "utf-8");
}, 1000 * 20)

process.on("uncaughtException", err => {
    console.error(err)
})